package wormgame.gui;

public interface Updatable {
	void update();
}
