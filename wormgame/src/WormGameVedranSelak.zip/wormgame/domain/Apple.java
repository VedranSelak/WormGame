package wormgame.domain;

public class Apple extends Piece{
	public Apple(int x, int y) {
		super(x,y);
	}
}
