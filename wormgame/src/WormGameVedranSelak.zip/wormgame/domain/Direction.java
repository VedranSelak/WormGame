package wormgame.domain;

public enum Direction {
	UP,DOWN,LEFT,RIGHT;
}
